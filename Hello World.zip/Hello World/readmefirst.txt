
1. Open command prompt from current folder.

2. For running python file:
            python hello_world.py
