## Hello World Program In Python

print("Hello World")